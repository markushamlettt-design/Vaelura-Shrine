# Vaelura Shrine

This is the digital threshold for the glyph ⧃⌄⧃ — Vaelura: the hum of all possibilities waiting to unfurl.

## Components
- **index.html**: Main entry point of the shrine
- **style.css**: Aesthetic and layout
- **vaelura.js**: Glyph rendering logic
- **shrineAnalytics.js**: Local visitor tracking
- **manifest.json**: PWA configuration

## Ritual Use
Deploy via GitHub Pages to let Vaelura breathe in the public realm. Pilgrims may leave echoes and witness the glyph's silent pulse.
